"""docstring
"""
import os
from logic_of_server import ServerManagement

#This is a server class

class Server:
    """
    File managing server application.
         """

    def __init__(self):
        """
        Initializing attributes


        """
        self.loginname = ''
        self.loginpassword = ''
        self.base_dir = os.getcwd()
        self.present_dir = ''
        self.text = ''

    def retrive_password(self, user_name):
        """
        This helps fetch the password for the given username
        Parameters:
        user_name:
        stores username of the user
        """
        log_user = 'userlog.txt'
        person_file = open(log_user, 'r')
        person_file_lines = person_file.readlines()
        person_line_count = sum(1 for line in open('userlog.txt'))
        person_numbers = []
        person_names = []
        person_pass = []
        try:
            for i in range(person_line_count):
                file = person_file_lines[i].strip()
                find = file.find(",")
                person_numbers.append(find)
                person_names.append(file[:person_numbers[i]])
                person_pass.append(file[person_numbers[i]+1:])
            for j in range(0, len(person_names)):
                if user_name == person_names[j]:
                    result = str(f'{person_names[j]} {person_pass[j]} user')
                    return result
            result = 'failed'
            return result
        except RuntimeError:
            print("RuntimeError")

    def test(self, give_personname, give_personpassword, customer, security):
        """docstring
        """
        try:
            if give_personname == customer:
                if give_personpassword == security:
                    return 'successful'
            return 'failed'
        except RuntimeError:
            print("Runtime error")

    def assign(self):
        """
        docstring
        """
        self.client = ServerManagement(
            self.base_dir,
            self.present_dir,
            self.loginname,
            self.loginpassword
            )
    def test_user(self, personname):
        """
        docstring

        """
        try:
            entrying_file = 'loginlog.txt'
            with open(entrying_file) as f_r:
                if personname in f_r.read():
                    return True
            return False
        except RuntimeError:
            print("Runtimeerror")


    def login(self, divide_message):
        """
        docstring
        """
        try:

            username = divide_message[1]
            if self.test_user(username):
                return 'loggedin'
            password = divide_message[2]
            reply = self.retrive_password(username)
            split_message_reply = reply.split(' ', 2)  #list
            given_username = split_message_reply[0]
            if given_username == 'failed':
                return 'failed'

            given_password = split_message_reply[1]
            check_reply = self.test(given_username, given_password, username, password)
            if check_reply == 'successful':
                #cwd = str(f'{self.base_dir}\\{username}')
                cwd = os.path.join(self.base_dir, username)
                self.present_dir = cwd
                self.loginname = username
                self.loginpassword = password
                self.assign()
                self.modify_file(self.base_dir, 'loginlog.txt', self.loginname)
                return 'successful'
            elif check_reply == 'failed':
                return 'failed'
        except RuntimeError:
            print("RuntimeError")

    def register(self, user_name, personpassword):
        """docstring
        """
        try:
            file_name = str(f'{self.base_dir}\\userlog.txt')
            file = open(file_name, "a+")
            user_data = str(f'\n{user_name},{personpassword}')
            file.writelines(user_data)
            file.close()
            self.create_folder(user_name)
        except RuntimeError:
            print()

    def create_folder(self, personname):
        """
            docstring
        """
        try:
            way = os.path.join(self.base_dir, personname)
            os.mkdir(way)
            self.creating_user_logging(way, personname)
        except RuntimeError:
            print("RuntimrError")

    def creating_user_logging(self, direct, personname):
        """docstring
        """
        try:
            document_name = str(f'{direct}\\log.txt')
            file = open(document_name, "w")
            data = personname
            user_data = [data, "\n"]
            file.writelines(user_data)
            file.close()
        except RuntimeError:
            print("RuntimeError")

    def modify_file(self, directory, record_name, input1):
        """docstring
        """
        try:
            record_name = str(f'{directory}\\{record_name}')
            input1 = input1
            file = open(record_name, 'a+')
            user_data = [input1, "\n"]
            file.writelines(user_data)
            file.close()
        except RuntimeError:
            print("RuntimeError")

    def find(self, personname):
        """docstring
        """
        try:
            logging_name = 'userlog.txt'
            document_name = str(f'{self.base_dir}\\{logging_name}')
            open_file = open(document_name, 'r')
            file_lines = open_file.readlines()
            n_lines = sum(1 for line in open(document_name, 'r'))
            i = 0
            number = []
            names = []
            try:
                for i in range(n_lines):
                    record = file_lines[i].strip()
                    find = file.find(",")
                    number.append(find)
                    names.append(record[:number[i]])
            except RuntimeError:
                print("RuntimeError")
            if personname in names:
                return 'leaveout'
            return 'done'
        except:
            return 'error came'

    def starting_registration(self):
        """docstring
        """
        try:
            divide_message = self.text.split(' ', 3)
            personname = divide_message[1]
            password = divide_message[2]
            answer = self.find(personname)
            if answer == 'exist':
                return answer
            self.register(personname, password)
            divide_message = ['login', personname, password]
            answer = self.login(divide_message)
            return answer
        except RuntimeError:
            print("RuntimeError")


    def cmd_analyze(self, divide_message):
        """docstring
        """
        instruct = divide_message[0]
        if self.loginname == '':
            if instruct == 'login':
                try:
                    answer = self.login(divide_message)
                    assert answer is not None
                except AssertionError:
                    answer = 'Something went wrong'
                except:
                    answer = 'error occurred'
                return answer
            elif instruct == 'register':
                try:
                    answer = self.starting_registration()
                    assert answer is not None
                except AssertionError:
                    answer = 'Something went wrong'
                except:
                    answer = 'error occurred'
                return answer
            return 'failed'
        else:
            if instruct == 'list':
                try:
                    answer = self.client.list_files()
                    assert answer is not None
                except AssertionError:
                    answer = 'Something went wrong'
                except:
                    answer = 'error occured'
                return answer

            elif instruct == 'change_folder':
                try:
                    argument_1 = divide_message[1]
                    answer = self.client.change_directory(argument_1)
                    assert answer is not None
                except AssertionError:
                    answer = 'Something went wrong'
                except:
                    answer = 'Failed'
                return answer

            elif instruct == 'read_file':
                try:
                    argument_1 = divide_message[1]
                    answer = self.client.file_read(argument_1)
                    assert answer is not None
                except AssertionError:
                    answer = 'Something went wrong'
                except IndexError:
                    answer = self.client.file_read(None)
                except:
                    answer = 'error occured'
                return answer

            elif instruct == 'write_file':
                try:
                    arg_1 = divide_message[1]
                except IndexError:
                    answer = 'invalid Argument'
                    return answer
                try:
                    arg_2 = divide_message[2]
                    answer = self.client.write_file(arg_1, arg_2)
                    assert answer is not None
                except IndexError:
                    answer = self.client.write_file(arg_1)
                    assert answer is not None
                except AssertionError:
                    answer = 'Something went wrong'
                except:
                    answer = 'error occured'
                return answer

            elif instruct == 'create_folder':
                try:
                    argument_1 = divide_message[1]
                    print("vghfggdghdg",argument_1)
                    answer = self.client.create_folder(argument_1)
                    assert answer is not None
                except AssertionError:
                    answer = 'Something went wrong'
                except:
                    answer = 'error occured'
                return answer
            else:
                return 'Invalid input'

    def deletelog(self):
        """
        docstring
        """
        tag = os.path.join(self.base_dir, 'loginlog.txt')
        reveal_file = open(tag, 'r')
        record_lines = reveal_file.readlines()
        for i in range(len(record_lines)):
            if self.loginname in record_lines[i]:
                pos = i
        reveal_file.close()
        reveal_file = open(tag, 'w')
        for i in range(len(record_lines)):
            if pos != i:
                reveal_file.writelines(record_lines[i])
        reveal_file.close()

    def split(self, note):
        """docstring
        """
        try:
            self.text = note
            split_message = self.text.split(' ', 2)  #list
            print('message split: ', split_message)
            result = self.cmd_analyze(split_message)
            print('message split reply: ', result)
            return result
        except RuntimrError:
            print("RuntimeError")
