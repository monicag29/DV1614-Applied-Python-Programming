"""
docstring
"""
import os
import datetime
import time
import shutil

class ServerManagement:
    """
    This module has services for user file management 
    for the server.
    Methods:
    __init__(self, root, current, user_id, password)
    list_files(self)
    create_folder(self, folder_name)
    write_file(self, file_name, input_data=None)
    file_read(self, record_name)
    view_file(self, file_name, entrypoint)
    change_directory(self, folder_name)
    """
    def __init__(self, root, current, user_id, password):
        """Initializing the attributes"""
        self.user_id = user_id
        self.password = password
        self.root = root
        self.current = current
        self.reading = ''
        self.begin = 0

    def list_files(self):
        """
         Lists all the files in the directory.
        """
        try:
            path = self.current
            file_lists = list(os.listdir(path))
            info = {}
            date_info = ['', '']
            reply = ''
            for single_file in file_lists:
                file_path = os.path.join(path, single_file)
                date_created = os.stat(file_path).st_ctime
                date_format = str("{}".format(datetime.datetime.strptime(time.ctime(date_created), "%a %b %d %H:%M:%S %Y")))
                stats = os.stat(file_path)
                info[single_file] = date_info.copy()
                info[single_file][0] = stats.st_size
                info[single_file][1] = date_format
            reply += '-------------------------------------------------------------------\n'
            for key in info:
                reply += str('{:20s}\t{:10} Bytes\t{:10}\n'.format(key, info[key][0], info[key][1]))
            return reply
        except OSError:
            print("OS error occured")

    def create_folder(self, folder_name):
        """
        Creates a file with the given folder_name.
        Parameters:
        folder_name:
        creates name of the file with the given folder_name
        """
        try:
            path = self.current+"\\"+folder_name
            os.mkdir(path)
        except:
            reply = 'failed to create folder'
            return reply
        reply = 'folder created'
        return reply

    

    def write_file(self, file_name, input_data=None):
        """
        writes content into the given file_name, if no file is present 
       then it creates a file with the given file_name.
       Parameters:
       file_name:
        name to the file which is being created
        input_data:
        stores the input to be written in the file
        """
        #path = os.path.join(self.current, file_name)
        try:
            path = self.current+"\\"+file_name
            if input_data is None:
                opened = open(path, 'w')
                opened.close()
                reply = 'File cleared'
                return reply

            opened = open(path, 'a')
            data = [input_data, "\n"]
            opened.writelines(data)
            opened.close()
            reply = 'file edited successfully'
            return reply
        except FileNotFoundError:
            print("file not found")


    def file_read(self, record_name):
        """
        reads the contents in the given record_name.
        parameters:
        record_name:
        the name of the file is given.
        """
        if record_name is None:
            if self.reading != '':
                self.reading = ''
                reply = 'File Closed'
                return reply
            reply = 'Invalid argument'
            return reply
        #path = os.path.join(self.current, record_name)
        path = self.current+"\\"+record_name
        try:
            if os.path.exists(path):
                if self.reading == record_name:
                    self.begin = self.begin+100
                    reply = self.view_file(path, self.begin)
                    return reply
                self.reading = record_name
                self.begin = 0
                reply = self.view_file(path, self.begin)
                return reply
            reply = 'file doesnot exist'
            return reply
        except PermissionError:
            reply = 'Requested file is a folder'
            return reply
        except:
            reply = 'error occured'
            return reply

    def view_file(self, file_name, entrypoint):
        """
        used to see contents of the file.
        Paramegters:
        file_name:
        name of the file to be viewed.
        entrypoint:
        the location from where the file is located
        """
        star = entrypoint+100
        file = open(file_name, "r")
        value = file.read()
        if star >= len(value):
            self.begin = 0
        return str(value[entrypoint:star])

    
    def change_directory(self, folder_name):
        """
        used to change the working directory.
        Parameters:
        folder_name:
        Name of the file which path is to be changed.
        """
        #path = self.reverse(self.root)
        path=self.root[::-1]
        num = path.find('\\')+1
        final_path = path[num:]
        print(final_path)
        inp = '..'
        try:
            if folder_name == inp:
                #reval = self.reverse(self.current)
                reval=self.current[::-1]
                num = reval.find('\\')+1
                new_path = reval[num:]
                #if self.reverse(new_path) == self.reverse(final_path):
                n_path=new_path[::-1]
                f_path=final_path[::-1]
                if n_path== f_path:
                    return 'access denied'
                #self.current = self.reverse(new_path)
                self.current=new_path[::-1]
                reply = 'directory changed to '+self.current
                return reply
            user_directory = os.path.join(self.current, folder_name)
            if os.path.isdir(user_directory):
                self.current = user_directory
                reply = 'directory changed to '+self.current
                return reply
            return 'file not found'
        except Exception as error:
            reply = f'Exception occured : {error}'
            return reply
        return 'error'
