""" server creation
"""
import asyncio
import signal
from server_main_class import Server

signal.signal(signal.SIGINT, signal.SIG_DFL)
USER_DICTIONARY = {}

async def handle_echo(reader, writer):
    """ Client-server solution for file management"""
    mark = writer.get_extra_info('peername')
    #server is connected 
    message = f"{mark} is attached !!!!"
    USER_DICTIONARY[mark[1]] = Server()
    print(message)
    while True:
        information = await reader.read(10000)
        message = information.decode().strip()
        if message == 'quit':
            USER_DICTIONARY[mark[1]].deletelog()
            break
        print(f"Got {message} from {mark}")
        reply = USER_DICTIONARY[mark[1]].split(message)
        print(f"forward: {reply}")
        if reply != '' or reply != 'None':
            writer.write(reply.encode())
        else:
            reply = '.'
            writer.write(reply.encode())
        await writer.drain()
    print("connection aborted")
    writer.close()

async def main():
    """
    this function will kick start the program
    """
    server_ip = '127.0.0.1'
    port = 8080
    loggingfile = open('loginlog.txt', 'w')
    loggingfile.close()
    server = await asyncio.start_server(handle_echo, server_ip, port)

    mark = server.sockets[0].getsockname()
    print(f'hosting on {mark}')

    async with server:
        await server.serve_forever()

asyncio.run(main())
