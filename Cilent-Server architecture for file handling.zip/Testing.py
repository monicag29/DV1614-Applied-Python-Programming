"""
The class Testsum s used the testing the sever logic with the class name servermanagement
"""
import os
import unittest
from logic_of_server import ServerManagement

class TestSum(unittest.TestCase):
    """
     here we are doing the unit testing   ia ma performing 2 types of unit testing
    """
    def test_folder_creation(self):
        """

        test_folder_creation this case specifics the creation pf folder is failure or success
        """
        user = ServerManagement(os.getcwd(), os.getcwd(), 'monica','1234')
        input_data = [
            'Test_folder','Test_folder'
        ]
        expectes_data = [
            'failed to create folder',
            'failed to create folder'
        ]
        answer = []
        for inputv in input_data:
            answer.append(user.create_folder(inputv))
        self.assertListEqual(answer, expectes_data)



    def test_read_file(self):
        """
        test read file checks the file read test case weather its is reading the file or not

        """
        userpath = os.path.join(os.getcwd(), 'monica')
        user = ServerManagement(os.getcwd(), userpath, 'monica','1234')
        input_data = [

            ['te.txt'],
            ['as.txt'],
            ['he.txt']
        ]
        expectes_data = [
            'file doesnot exist',
            'file doesnot exist',
            ''

        ]
        answer = []
        for inputv in input_data:
            answer.append(user.file_read(inputv[0]))
        self.assertListEqual(answer, expectes_data)

if __name__ == '__main__':
    unittest.main()
