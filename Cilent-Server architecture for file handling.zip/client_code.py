"""
Client started
"""
import asyncio

ISSUED = ''
def Entry():
    """
    The Entry method is used for login and register commands
    """
    print('client-server solution ')
    while True:
        print('1 :User Login ')
        print('2 :User Register ')
        choice = input('Enter the Choice(1,2): ')
        if choice == '1':
            result = login()
            return result
        elif choice == '2':
            result = register()
            return result
        print('Invalid Input ')

def process(message):
    """
    Command which are need to be send to the server.
    """
    divide_message = message.split(' ', 1)
    command = divide_message[0]
    c_argument = len(divide_message)
    global ISSUED
    if command == 'commands':
        if c_argument == 1:
            c_file = open('commands.txt', 'r')
            content = c_file.read()
            print(content)
            return False
        elif c_argument == 2:
            argument = divide_message[1]
            if argument == 'issued':
                print(ISSUED)
                return False
            elif argument == 'clear':
                ISSUED = ''
                print('Cleared')
                return False
            print('Invalid command')
            return False
        print('invalid arguments')
        return False
    ISSUED += str('\n'+message)
    return True

def login():
    """
    The login method is used to login the user
    """
    print('User Login ')
    user_name = input('User Name : ')
    password = input('User Password : ')
    result = str(f'login {user_name} {password}')
    return result

def register():
    """
    This method is used to register the new user
    """
    print('User Register ')
    user_name = input('user enter wanted user name : ')
    password = input('enter wanted password : ')    
    result = str(f'register {user_name} {password} ')
    print(result)
    return result

async def server_connect():
    """
    this method helps  client to connect to the server
    """
    reader, writer = await asyncio.open_connection('127.0.0.1', 8080)
    infomation = ''

    while True:
        request = Entry()
        writer.write(request.encode())
        data = await reader.read(10000)
        information = data.decode()
        if information == 'successful':
            print('User Login done ')
            break
        elif information == 'Created':
            print(' user Created')
            break
        elif information == 'exist':
            print('User Already present ')
            print('please use the new user name')
            continue
        elif information == 'failed':
            print('Login cancled ')
            print('Try Again')
            continue
        elif information == 'invalid':
            print('invalid input ')
            continue
        elif information == 'loggedin':
            print('user already there and logged in another client')
            continue
        else:
            print('Error has Occured, Please Try Again ')
            continue

    while True:
        information = input('>')

        if information == 'quit':
            writer.write(information.encode())
            break
        elif information == '':
            continue
        reply = process(information)
        if reply:
            writer.write(information.encode())
            data = await reader.read(10000)
            print(f'{data.decode()}')
    print('connection aborted')
    writer.close()

try:
    asyncio.run(server_connect())
except ConnectionRefusedError:
    print('unable to connect to server')
